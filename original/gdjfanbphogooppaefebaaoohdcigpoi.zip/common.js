var sessionId = document.cookie.match('sid=([^;]*)')[1];
var serverUrl  = window.location.protocol + "//" + window.location.host;

